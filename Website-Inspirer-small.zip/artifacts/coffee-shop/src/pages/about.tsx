import { motion } from "framer-motion";

const fadeIn = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: "easeOut" } }
};

export default function About() {
  return (
    <div className="bg-background">
      {/* Hero Section */}
      <section className="relative h-[60vh] flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat z-0"
          style={{ 
            backgroundImage: "url('https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?auto=format&fit=crop&q=80&w=2000')",
            filter: "brightness(0.5)"
          }}
        />
        <div className="container relative z-10 mx-auto px-6 text-center text-white">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="font-serif text-5xl md:text-7xl font-bold mb-6"
          >
            Our Story
          </motion.h1>
        </div>
      </section>

      {/* Mission */}
      <section className="py-24">
        <div className="container mx-auto px-6 max-w-4xl text-center">
          <motion.h2 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
            className="font-serif text-3xl md:text-4xl leading-relaxed mb-8"
          >
            "We opened Moka & Co. with a singular conviction: that a neighborhood café should offer the uncompromising quality of a fine dining establishment, without the pretense."
          </motion.h2>
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
            className="w-16 h-px bg-accent mx-auto"
          />
        </div>
      </section>

      {/* Sourcing */}
      <section className="py-24 bg-secondary">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center gap-16">
            <div className="md:w-1/2">
              <img 
                src="https://images.unsplash.com/photo-1559525839-b184a4d698c7?auto=format&fit=crop&q=80&w=1000" 
                alt="Coffee Beans" 
                className="w-full h-[600px] object-cover rounded-sm shadow-xl"
              />
            </div>
            <div className="md:w-1/2">
              <span className="text-accent uppercase text-sm tracking-widest font-semibold block mb-4">Direct Trade</span>
              <h2 className="font-serif text-4xl mb-6">From Farm to Cup</h2>
              <div className="space-y-6 text-muted-foreground leading-relaxed">
                <p>
                  We don't buy from brokers. Every bean we roast is sourced directly from farmers we know by name in Colombia, Ethiopia, and Sumatra. 
                </p>
                <p>
                  By paying premium prices directly to the growers, we ensure sustainable farming practices and secure the highest grade microlots before they reach the general market.
                </p>
                <p>
                  Our roasting process is meticulous. We roast in small, 5kg batches, adjusting heat and airflow second by second to bring out the intrinsic terroir of each origin.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-24">
        <div className="container mx-auto px-6 max-w-4xl">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl md:text-5xl mb-4">Our Journey</h2>
            <p className="text-muted-foreground">The milestones that shaped who we are today.</p>
          </div>
          
          <div className="space-y-12 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-border before:to-transparent">
            {[
              { year: "1994", title: "The First Pour", desc: "Moka & Co. opened its doors as a humble 400-square-foot roastery, focusing entirely on single-origin espressos." },
              { year: "2002", title: "Direct Trade Pioneer", desc: "We bypassed traditional brokers to establish our first direct relationship with a cooperative in Yirgacheffe, Ethiopia." },
              { year: "2015", title: "The Tasting Room", desc: "Expansion into our current space, allowing us to introduce our in-house pastry program and cupping lab." },
              { year: "2023", title: "Decade of Excellence", desc: "Awarded 'Best Independent Roaster' for the third consecutive year by the Specialty Coffee Association." }
            ].map((item, idx) => (
              <motion.div 
                key={idx}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-50px" }}
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
                }}
                className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active"
              >
                <div className="flex items-center justify-center w-10 h-10 rounded-full border-4 border-background bg-accent text-white shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10">
                  <div className="w-2 h-2 bg-white rounded-full" />
                </div>
                <div className="w-[calc(100%-4rem)] md:w-[calc(50%-3rem)] bg-card border border-border p-6 shadow-sm hover:border-accent transition-colors duration-300">
                  <span className="font-serif text-accent text-xl block mb-2">{item.year}</span>
                  <h3 className="font-serif text-2xl mb-2">{item.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-24">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl md:text-5xl mb-4">The Artisans</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our team consists of certified Q-graders, competitive latte artists, and pastry chefs dedicated to their craft.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              {
                name: "Marcus Thorne",
                role: "Founder & Head Roaster",
                img: "https://images.unsplash.com/photo-1583336214539-786d34eec319?auto=format&fit=crop&q=80&w=600",
                bio: "Marcus spent a decade working on coffee farms in Central America before returning home to establish Moka & Co."
              },
              {
                name: "Elena Rostova",
                role: "Lead Barista",
                img: "https://images.unsplash.com/photo-1506836467174-27f1042aa48c?auto=format&fit=crop&q=80&w=600",
                bio: "A two-time regional barista champion, Elena oversees extraction protocols and staff training."
              },
              {
                name: "David Chen",
                role: "Executive Pastry Chef",
                img: "https://images.unsplash.com/photo-1553531087-b25a0b9a68ab?auto=format&fit=crop&q=80&w=600",
                bio: "Trained in Paris, David combines classic French technique with local, seasonal ingredients."
              }
            ].map((person, idx) => (
              <motion.div 
                key={idx}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-50px" }}
                variants={{
                  hidden: { opacity: 0, y: 30 },
                  visible: { opacity: 1, y: 0, transition: { delay: idx * 0.2, duration: 0.8 } }
                }}
                className="group"
              >
                <div className="overflow-hidden mb-6 aspect-square rounded-full w-48 h-48 mx-auto grayscale group-hover:grayscale-0 transition-all duration-500">
                  <img src={person.img} alt={person.name} className="w-full h-full object-cover" />
                </div>
                <div className="text-center">
                  <h3 className="font-serif text-2xl mb-1">{person.name}</h3>
                  <span className="text-accent text-sm uppercase tracking-wider block mb-4">{person.role}</span>
                  <p className="text-muted-foreground text-sm leading-relaxed">{person.bio}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
