import { useState } from "react";
import { motion } from "framer-motion";
import { Mail, Phone, MapPin, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Contact() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      (e.target as HTMLFormElement).reset();
      toast({
        title: "Message Sent",
        description: "Thank you for reaching out. We will get back to you shortly.",
      });
    }, 1500);
  };

  return (
    <div className="bg-background pt-24 pb-32">
      <div className="container mx-auto px-6">
        
        <div className="text-center mb-16">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-serif text-5xl md:text-6xl mb-4"
          >
            Get in Touch
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-muted-foreground max-w-2xl mx-auto"
          >
            Whether you have a question about our beans, want to discuss catering, or just want to say hello, we'd love to hear from you.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          {/* Left: Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-card border border-border p-8 md:p-12 shadow-sm"
          >
            <h2 className="font-serif text-3xl mb-8">Send a Message</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="name" className="text-sm font-medium">Name</label>
                  <input 
                    id="name"
                    type="text" 
                    required
                    className="w-full border-b border-primary/20 bg-transparent py-2 focus:outline-none focus:border-primary transition-colors"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="email" className="text-sm font-medium">Email</label>
                  <input 
                    id="email"
                    type="email" 
                    required
                    className="w-full border-b border-primary/20 bg-transparent py-2 focus:outline-none focus:border-primary transition-colors"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <label htmlFor="phone" className="text-sm font-medium">Phone (optional)</label>
                <input 
                  id="phone"
                  type="tel" 
                  className="w-full border-b border-primary/20 bg-transparent py-2 focus:outline-none focus:border-primary transition-colors"
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="message" className="text-sm font-medium">Message</label>
                <textarea 
                  id="message"
                  rows={5}
                  required
                  className="w-full border-b border-primary/20 bg-transparent py-2 focus:outline-none focus:border-primary transition-colors resize-none"
                ></textarea>
              </div>

              <button 
                type="submit" 
                disabled={isSubmitting}
                className="w-full bg-primary text-primary-foreground py-4 uppercase text-sm tracking-wider hover:bg-accent transition-colors disabled:opacity-70"
              >
                {isSubmitting ? "Sending..." : "Send Message"}
              </button>
            </form>
          </motion.div>

          {/* Right: Info & Map */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="space-y-12"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="flex gap-4">
                <MapPin className="h-6 w-6 text-accent shrink-0" />
                <div>
                  <h3 className="font-serif text-xl mb-2">Location</h3>
                  <p className="text-muted-foreground text-sm">123 Coffee Lane<br/>Downtown District<br/>Cityville, ST 12345</p>
                </div>
              </div>
              
              <div className="flex gap-4">
                <Clock className="h-6 w-6 text-accent shrink-0" />
                <div>
                  <h3 className="font-serif text-xl mb-2">Hours</h3>
                  <p className="text-muted-foreground text-sm">Mon-Fri: 7am - 6pm<br/>Sat: 8am - 7pm<br/>Sun: 8am - 5pm</p>
                </div>
              </div>

              <div className="flex gap-4">
                <Phone className="h-6 w-6 text-accent shrink-0" />
                <div>
                  <h3 className="font-serif text-xl mb-2">Phone</h3>
                  <p className="text-muted-foreground text-sm">(555) 123-4567</p>
                </div>
              </div>

              <div className="flex gap-4">
                <Mail className="h-6 w-6 text-accent shrink-0" />
                <div>
                  <h3 className="font-serif text-xl mb-2">Email</h3>
                  <p className="text-muted-foreground text-sm">hello@mokaandco.com</p>
                </div>
              </div>
            </div>

            {/* Map Placeholder */}
            <div className="h-64 w-full bg-secondary relative overflow-hidden border border-border group">
              <div className="absolute inset-0 bg-black/10 group-hover:bg-black/0 transition-colors z-10 pointer-events-none" />
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d193595.15830869428!2d-74.119763973046!3d40.69766374874431!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2s!4v1700000000000!5m2!1sen!2s" 
                width="100%" 
                height="100%" 
                style={{ border: 0, filter: "grayscale(1) contrast(1.2) opacity(0.8)" }} 
                allowFullScreen={false} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                className="absolute inset-0"
              ></iframe>
            </div>
            
          </motion.div>
        </div>
      </div>
    </div>
  );
}
