import { Link } from "wouter";
import { Coffee, Instagram, Twitter, Facebook } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground py-16 md:py-24">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-6">
              <Coffee className="h-6 w-6 text-accent" />
              <span className="font-serif text-2xl font-bold tracking-wider">Moka & Co.</span>
            </Link>
            <p className="text-primary-foreground/70 text-sm leading-relaxed mb-6 max-w-xs">
              A luxury specialty coffee house in the heart of the city, serving single-origin espresso drinks and handcrafted pastries to discerning regulars.
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="w-10 h-10 rounded-full border border-primary-foreground/20 flex items-center justify-center hover:bg-accent hover:border-accent transition-colors">
                <Instagram className="h-4 w-4" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full border border-primary-foreground/20 flex items-center justify-center hover:bg-accent hover:border-accent transition-colors">
                <Twitter className="h-4 w-4" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full border border-primary-foreground/20 flex items-center justify-center hover:bg-accent hover:border-accent transition-colors">
                <Facebook className="h-4 w-4" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-serif text-lg mb-6 font-semibold">Visit Us</h4>
            <address className="not-italic text-sm text-primary-foreground/70 space-y-2">
              <p>123 Coffee Lane</p>
              <p>Downtown District</p>
              <p>Cityville, ST 12345</p>
            </address>
          </div>

          <div>
            <h4 className="font-serif text-lg mb-6 font-semibold">Hours</h4>
            <div className="text-sm text-primary-foreground/70 space-y-2">
              <p className="flex justify-between max-w-[200px]"><span>Mon - Fri</span> <span>7:00 AM - 6:00 PM</span></p>
              <p className="flex justify-between max-w-[200px]"><span>Saturday</span> <span>8:00 AM - 7:00 PM</span></p>
              <p className="flex justify-between max-w-[200px]"><span>Sunday</span> <span>8:00 AM - 5:00 PM</span></p>
            </div>
          </div>

          <div>
            <h4 className="font-serif text-lg mb-6 font-semibold">Links</h4>
            <ul className="text-sm text-primary-foreground/70 space-y-3">
              <li><Link href="/menu" className="hover:text-accent transition-colors">Our Menu</Link></li>
              <li><Link href="/about" className="hover:text-accent transition-colors">Our Story</Link></li>
              <li><Link href="/contact" className="hover:text-accent transition-colors">Contact Us</Link></li>
              <li><Link href="#" className="hover:text-accent transition-colors">Careers</Link></li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-primary-foreground/10 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-primary-foreground/50">
          <p>&copy; {new Date().getFullYear()} Moka & Co. All rights reserved.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-accent transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-accent transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
