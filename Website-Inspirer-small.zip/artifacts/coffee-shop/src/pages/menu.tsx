import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search } from "lucide-react";

type Category = "All" | "Espresso" | "Cappuccino" | "Latte" | "Americano" | "Mocha" | "Iced Coffee" | "Tea" | "Pastries";

interface MenuItem {
  name: string;
  category: string;
  description: string;
  price: string;
  isPopular?: boolean;
}

const menuItems: MenuItem[] = [
  // Espresso
  { name: "Single Espresso", category: "Espresso", description: "A highly concentrated, intensely flavored shot.", price: "$3.00" },
  { name: "Double Espresso (Doppio)", category: "Espresso", description: "Two shots of espresso extracted using our house blend.", price: "$3.75" },
  { name: "Macchiato", category: "Espresso", description: "Double espresso with a dollop of steamed milk foam.", price: "$4.25", isPopular: true },
  
  // Cappuccino
  { name: "Classic Cappuccino", category: "Cappuccino", description: "Equal parts espresso, steamed milk, and thick milk foam.", price: "$4.50" },
  { name: "Dry Cappuccino", category: "Cappuccino", description: "Espresso topped almost entirely with milk foam.", price: "$4.50" },
  
  // Latte
  { name: "Café Latte", category: "Latte", description: "Espresso with steamed milk and a light layer of foam.", price: "$4.75" },
  { name: "Vanilla Bean Latte", category: "Latte", description: "Latte infused with real Madagascar vanilla bean syrup.", price: "$5.50", isPopular: true },
  { name: "Oat Milk Flat White", category: "Latte", description: "Ristretto shots layered with velvety oat milk.", price: "$5.00" },
  
  // Americano
  { name: "Caffè Americano", category: "Americano", description: "Double shot of espresso diluted with hot water.", price: "$3.50" },
  { name: "Long Black", category: "Americano", description: "Hot water topped with a double ristretto.", price: "$4.00" },
  
  // Mocha
  { name: "Dark Chocolate Mocha", category: "Mocha", description: "Espresso, steamed milk, and 70% dark chocolate ganache.", price: "$5.50", isPopular: true },
  { name: "White Chocolate Mocha", category: "Mocha", description: "Espresso, steamed milk, and sweet white chocolate.", price: "$5.50" },
  
  // Iced Coffee
  { name: "Cold Brew", category: "Iced Coffee", description: "Slow-steeped for 18 hours for a smooth, low-acidity finish.", price: "$4.50" },
  { name: "Iced Caramel Macchiato", category: "Iced Coffee", description: "Espresso poured over milk and ice, with caramel drizzle.", price: "$5.75" },
  { name: "Nitro Draft", category: "Iced Coffee", description: "Cold brew infused with nitrogen for a creamy, stout-like texture.", price: "$5.25", isPopular: true },
  
  // Tea
  { name: "Earl Grey Reserve", category: "Tea", description: "Premium black tea with bergamot oil and cornflower.", price: "$3.75" },
  { name: "Matcha Latte", category: "Tea", description: "Ceremonial grade matcha whisked with steamed milk.", price: "$5.50", isPopular: true },
  { name: "Chamomile Citrus", category: "Tea", description: "Caffeine-free herbal blend with soothing floral notes.", price: "$3.75" },
  
  // Pastries
  { name: "Butter Croissant", category: "Pastries", description: "Classic, flaky, and baked fresh every morning.", price: "$4.00" },
  { name: "Almond Croissant", category: "Pastries", description: "Filled with almond frangipane and topped with sliced almonds.", price: "$5.50", isPopular: true },
  { name: "Lemon Poppyseed Loaf", category: "Pastries", description: "Moist cake slice with a tart lemon glaze.", price: "$4.50" },
  { name: "Dark Chocolate Babka", category: "Pastries", description: "Twisted sweet dough layered with rich chocolate.", price: "$5.00" },
];

const categories: Category[] = ["All", "Espresso", "Cappuccino", "Latte", "Americano", "Mocha", "Iced Coffee", "Tea", "Pastries"];

export default function Menu() {
  const [activeCategory, setActiveCategory] = useState<Category>("All");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredItems = menuItems.filter(item => {
    const matchesCategory = activeCategory === "All" || item.category === activeCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="bg-background min-h-screen pt-24 pb-32">
      <div className="container mx-auto px-6">
        
        {/* Header */}
        <div className="text-center mb-16">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-serif text-5xl md:text-6xl mb-4"
          >
            Our Offerings
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-muted-foreground max-w-2xl mx-auto"
          >
            Every beverage is crafted to exacting standards using carefully sourced beans and precise extraction methods. 
          </motion.p>
        </div>

        {/* Filters and Search */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-6 mb-12">
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  activeCategory === cat 
                    ? "bg-primary text-primary-foreground" 
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input 
              type="text"
              placeholder="Search menu..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border-b border-primary/20 bg-transparent focus:outline-none focus:border-primary transition-colors"
            />
          </div>
        </div>

        {/* Menu Grid */}
        <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <AnimatePresence>
            {filteredItems.map((item) => (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                key={item.name}
                className="group p-6 border border-border bg-card hover:border-accent hover:shadow-md transition-all duration-300"
              >
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-serif text-xl font-medium text-card-foreground flex items-center gap-2">
                      {item.name}
                      {item.isPopular && (
                        <span className="text-[10px] uppercase tracking-wider bg-accent/10 text-accent px-2 py-0.5 rounded-full">
                          Popular
                        </span>
                      )}
                    </h3>
                    <span className="text-xs uppercase tracking-widest text-muted-foreground mt-1 block">
                      {item.category}
                    </span>
                  </div>
                  <span className="font-semibold text-accent shrink-0">{item.price}</span>
                </div>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {item.description}
                </p>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {filteredItems.length === 0 && (
          <div className="text-center py-20 text-muted-foreground">
            No items found matching your search.
          </div>
        )}

      </div>
    </div>
  );
}
