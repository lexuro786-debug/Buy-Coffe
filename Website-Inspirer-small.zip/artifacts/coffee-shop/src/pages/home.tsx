import { motion } from "framer-motion";
import { ArrowRight, Star } from "lucide-react";
import { Link } from "wouter";
import { AnimatedCounter } from "@/components/ui/animated-counter";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";

const fadeIn = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: "easeOut" } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2
    }
  }
};

export default function Home() {
  return (
    <div className="bg-background">
      {/* Hero Section */}
      <section className="relative h-[100dvh] flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat z-0"
          style={{ 
            backgroundImage: "url('https://images.unsplash.com/photo-1497935586351-b67a49e012bf?auto=format&fit=crop&q=80&w=2000')",
            filter: "brightness(0.65)"
          }}
        />
        <div className="container relative z-10 mx-auto px-6 text-center text-white flex flex-col items-center">
          <motion.span 
            initial={{ opacity: 0, tracking: "normal" }}
            animate={{ opacity: 1, tracking: "0.2em" }}
            transition={{ duration: 1, delay: 0.2 }}
            className="uppercase text-sm tracking-[0.2em] mb-4 text-white/80"
          >
            Since 1994
          </motion.span>
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="font-serif text-5xl md:text-7xl lg:text-8xl font-bold mb-6 max-w-4xl leading-tight"
          >
            The Art of Perfect Extraction
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="text-lg md:text-xl max-w-xl mx-auto mb-10 text-white/90 font-light"
          >
            A sanctuary for discerning coffee lovers in the heart of the city. We roast, pull, and pour with uncompromising precision.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
          >
            <Link href="/menu" className="inline-flex items-center gap-2 bg-accent text-white px-8 py-4 uppercase text-sm tracking-wider font-semibold hover:bg-white hover:text-accent transition-colors duration-300">
              Explore Our Menu <ArrowRight className="h-4 w-4" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Philosophy Section */}
      <section className="py-24 md:py-32 bg-secondary relative">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center gap-16 lg:gap-24">
            <motion.div 
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
              variants={fadeIn}
              className="md:w-1/2"
            >
              <h2 className="font-serif text-4xl md:text-5xl mb-8 leading-tight">Time slows down when the cup is right.</h2>
              <div className="space-y-6 text-muted-foreground leading-relaxed">
                <p>
                  At Moka & Co., we believe that coffee is more than caffeine. It's a ritual, a moment of pause in a restless city, a craft that demands respect.
                </p>
                <p>
                  Every bean we serve is ethically sourced from high-altitude farms, roasted locally to highlight its distinct terroir, and pulled by baristas who treat extraction as both science and art.
                </p>
              </div>
              <Link href="/about" className="inline-block mt-8 border-b border-accent text-accent uppercase text-sm tracking-widest pb-1 hover:text-primary hover:border-primary transition-colors">
                Read our story
              </Link>
            </motion.div>
            <div className="md:w-1/2 w-full">
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 1 }}
                className="aspect-[4/5] relative overflow-hidden"
              >
                <img 
                  src="https://images.unsplash.com/photo-1495474472206-bf5f28b8f40b?auto=format&fit=crop&q=80&w=1000" 
                  alt="Barista pouring latte art" 
                  className="object-cover w-full h-full hover:scale-105 transition-transform duration-1000"
                />
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Menu */}
      <section className="py-24 md:py-32">
        <div className="container mx-auto px-6">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeIn}
            className="text-center mb-16"
          >
            <span className="text-accent uppercase text-sm tracking-widest font-semibold block mb-4">Curated Selection</span>
            <h2 className="font-serif text-4xl md:text-5xl">House Signatures</h2>
          </motion.div>

          <motion.div 
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
          >
            {[
              {
                title: "Oaxaca Single Origin",
                desc: "Bright acidity with notes of jasmine, milk chocolate, and sweet orange.",
                img: "https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?auto=format&fit=crop&q=80&w=800",
                price: "$4.50"
              },
              {
                title: "Cardamom Cortado",
                desc: "Equal parts espresso and steamed milk, infused with crushed green cardamom.",
                img: "https://images.unsplash.com/photo-1559525839-b184a4d698c7?auto=format&fit=crop&q=80&w=800",
                price: "$5.25"
              },
              {
                title: "Pistachio Croissant",
                desc: "Twice-baked flaky pastry filled with pistachio frangipane. Baked fresh hourly.",
                img: "https://images.unsplash.com/photo-1608198093002-ad4e005484ec?auto=format&fit=crop&q=80&w=800",
                price: "$6.00"
              }
            ].map((item, idx) => (
              <motion.div key={idx} variants={fadeIn} className="group cursor-pointer">
                <div className="overflow-hidden aspect-[4/5] mb-6">
                  <img src={item.img} alt={item.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                </div>
                <div className="flex justify-between items-baseline mb-2">
                  <h3 className="font-serif text-xl">{item.title}</h3>
                  <span className="text-accent font-semibold">{item.price}</span>
                </div>
                <p className="text-muted-foreground text-sm leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </motion.div>

          <div className="text-center mt-16">
            <Link href="/menu" className="inline-block border border-primary px-8 py-3 uppercase text-sm tracking-wider hover:bg-primary hover:text-primary-foreground transition-colors">
              View Full Menu
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Parallax */}
      <section className="py-24 relative bg-primary text-primary-foreground">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-10 text-center">
            <div>
              <div className="font-serif text-5xl md:text-6xl text-accent mb-2">
                <AnimatedCounter to={1994} duration={2.5} />
              </div>
              <div className="uppercase text-xs tracking-widest text-primary-foreground/70">Est. Year</div>
            </div>
            <div>
              <div className="font-serif text-5xl md:text-6xl text-accent mb-2">
                <AnimatedCounter to={3} duration={2} />
              </div>
              <div className="uppercase text-xs tracking-widest text-primary-foreground/70">Master Roasters</div>
            </div>
            <div>
              <div className="font-serif text-5xl md:text-6xl text-accent mb-2">
                <AnimatedCounter to={12} duration={2} />
              </div>
              <div className="uppercase text-xs tracking-widest text-primary-foreground/70">Single Origins</div>
            </div>
            <div>
              <div className="font-serif text-5xl md:text-6xl text-accent mb-2">
                <AnimatedCounter to={100} duration={2} suffix="k+" />
              </div>
              <div className="uppercase text-xs tracking-widest text-primary-foreground/70">Cups Poured</div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 md:py-32 bg-secondary">
        <div className="container mx-auto px-6 max-w-4xl text-center">
          <Star className="h-8 w-8 text-accent mx-auto mb-8" />
          <Carousel opts={{ loop: true }} className="w-full">
            <CarouselContent>
              {[
                { text: "The only place in the city where I can trust the espresso to be perfect every single time. It's not just a cafe; it's a morning sanctuary.", author: "Eleanor V." },
                { text: "Their attention to detail is unmatched. The barista remembered my order by my third visit. The cardamom cortado is life-changing.", author: "Marcus T." },
                { text: "Beautiful space, incredible pastries, and coffee that actually tastes like the tasting notes on the bag. A rare find.", author: "Sarah H." },
              ].map((item, index) => (
                <CarouselItem key={index}>
                  <div className="px-4">
                    <p className="font-serif text-2xl md:text-3xl leading-relaxed mb-8 italic text-foreground/90">
                      "{item.text}"
                    </p>
                    <p className="uppercase tracking-widest text-sm font-semibold text-accent">— {item.author}</p>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="hidden md:flex -left-12 border-primary/20 hover:bg-primary hover:text-primary-foreground" />
            <CarouselNext className="hidden md:flex -right-12 border-primary/20 hover:bg-primary hover:text-primary-foreground" />
          </Carousel>
        </div>
      </section>

      {/* Newsletter / CTA */}
      <section className="py-24 md:py-32">
        <div className="container mx-auto px-6 max-w-3xl text-center">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="font-serif text-4xl mb-4">Join the Inner Circle</h2>
            <p className="text-muted-foreground mb-10">Subscribe to receive updates on rare bean drops, seasonal pastries, and exclusive brewing workshops.</p>
            <form className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto" onSubmit={(e) => e.preventDefault()}>
              <input 
                type="email" 
                placeholder="Your email address" 
                className="flex-1 bg-transparent border-b border-primary/30 py-3 px-4 focus:outline-none focus:border-primary transition-colors placeholder:text-muted-foreground/60"
                required
              />
              <button type="submit" className="bg-primary text-primary-foreground px-8 py-3 uppercase text-sm tracking-wider hover:bg-accent transition-colors">
                Subscribe
              </button>
            </form>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
